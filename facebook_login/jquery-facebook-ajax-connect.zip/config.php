<?php
########## app ID and app SECRET (Replace with yours) #############
$appId = '29837497497'; //Facebook App ID
$appSecret = '9dsfdw987er987sdf98w987df98s7df'; // Facebook App Secret
$return_url = 'http://localhost/facebook/';  //path to script folder
$fbPermissions = 'publish_actions,email'; // more permissions : https://developers.facebook.com/docs/authentication/permissions/

########## MySql details (Replace with yours) #############
$db_username = "root"; //Database Username
$db_password = ""; //Database Password
$hostname = "localhost"; //Mysql Hostname
$db_name = 'demo'; //Database Name
###################################################################

?>